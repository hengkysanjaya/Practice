﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmonicAirline
{
    public partial class BookingConfirmationForm : Form
    {
        session3Entities entities = new session3Entities();
        List<List<Schedule>> schedules;
        int passenger, bookingType;
        CabinType cabinType;
        Form source;
        List<Passenger> passengers = new List<Passenger>();
        int id = 0;

        public BookingConfirmationForm(Form source, int bookingType, List<List<Schedule>> schedules, int passenger, CabinType cabinType)
        {
            InitializeComponent();

            this.source = source;
            this.bookingType = bookingType;
            this.schedules = schedules;
            this.passenger = passenger;
            this.cabinType = cabinType;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (passengers.Count < passenger)
            {
                string firstName = textBox1.Text.Trim();
                string lastName = textBox2.Text.Trim();
                DateTime birthdate = dateTimePicker1.Value;
                string passportNumber = textBox3.Text.Trim();
                string phone = maskedTextBox1.Text;

                if (firstName.Equals("") || lastName.Equals("") || passportNumber.Equals("") || phone.Contains(" ") || phone.Length != 8 || comboBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("All fields are required!");
                }
                else
                {
                    Country country = comboBox1.SelectedItem as Country;

                    Passenger ps = new Passenger()
                    {
                        ID = id++,
                        FirstName = firstName,
                        LastName = lastName,
                        Birthdate = birthdate,
                        Country = country,
                        PassportNumber = passportNumber,
                        Phone = phone
                    };

                    passengers.Add(ps);
                    RefreshDataGridView();
                }
            }
        }

        public void DestroyPreviousFrom()
        {
            source.Close();
        }

        private void RefreshDataGridView()
        {
            var p = passengers.Select(x => new
            {
                ID = x.ID,
                Firstname = x.FirstName,
                Lastname = x.LastName,
                Birthdate = x.Birthdate.ToString("dd-MM-yyyy"),
                PassportNumber = x.PassportNumber,
                PassportCountry = x.Country.Name,
                Phone = x.Phone
            }).ToList();

            dataGridView1.DataSource = p;
            dataGridView1.Columns["ID"].Visible = false;
            dataGridView1.CurrentCell = null;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            source.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(dataGridView1.CurrentCell == null)
            {
                MessageBox.Show("Please select passenger that you want to remove!");
            }
            else
            {
                DataGridViewCell cell = dataGridView1.CurrentCell;
                int id = (int)dataGridView1.Rows[cell.RowIndex].Cells["ID"].Value;

                Passenger p = passengers.Where(x => x.ID == id).FirstOrDefault();
                passengers.Remove(p);

                RefreshDataGridView();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(passengers.Count != passenger)
            {
                MessageBox.Show($"Please add {passenger} passenger data!");
            }
            else
            {
                BillingConfirmation form = new BillingConfirmation(this, bookingType, schedules, passenger, cabinType, passengers);
                form.Show();
                this.Hide();
            }
        }

        private void BookingConfirmationForm_Load(object sender, EventArgs e)
        {
            var passportCountry = entities.Countries.ToList();
            comboBox1.ValueMember = "ID";
            comboBox1.DisplayMember = "Name";
            comboBox1.DataSource = passportCountry;

            for (int i = 0; i < schedules[0].Count; i++)
            {
                FlightData uc = new FlightData(schedules[0][i].Route.Airport.IATACode,
                                               schedules[0][i].Route.Airport1.IATACode,
                                               cabinType.Name,
                                               schedules[0][i].Date.ToString("MM/dd/yyyy"),
                                               schedules[0][i].FlightNumber);

                flowLayoutPanel1.Controls.Add(uc);
            }

            if(bookingType == 2)
            {
                for (int i = 0; i < schedules[1].Count; i++)
                {
                    FlightData uc = new FlightData(schedules[1][i].Route.Airport.IATACode,
                                                   schedules[1][i].Route.Airport1.IATACode,
                                                   cabinType.Name,
                                                   schedules[1][i].Date.ToString("MM/dd/yyyy"),
                                                   schedules[1][i].FlightNumber);

                    flowLayoutPanel2.Controls.Add(uc);
                }

                groupBox2.Visible = true;
            }

            id = BillingConfirmation.GenerateUserId();
        }
    }
    public class Passenger
    {
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime Birthdate { get; set; }
        public string PassportNumber { get; set; }
        public Country Country { get; set; }
        public string Phone { get; set; }
    }
}
