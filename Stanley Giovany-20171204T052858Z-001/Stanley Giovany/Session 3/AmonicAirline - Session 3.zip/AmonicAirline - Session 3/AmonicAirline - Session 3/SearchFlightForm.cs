﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmonicAirline
{
    public partial class SearchFlightForm : Form
    {
        session3Entities entities = new session3Entities();
        List<List<Schedule>> outboundRoutes = new List<List<Schedule>>();
        List<List<Schedule>> returnRoutes = new List<List<Schedule>>();
        DateTime outboundDate, returnDate;
        CabinType cabinType;
        int bookingType;

        class Schedules
        {
            public List<Schedule> schedules { get; set; }
        }

        public SearchFlightForm()
        {
            InitializeComponent();
        }

        private void SearchFlightForm_Load(object sender, EventArgs e)
        {
            var fromAirport = entities.Airports.ToList();
            comboBox1.DisplayMember = "IATACode";
            comboBox1.ValueMember = "ID";
            comboBox1.DataSource = fromAirport;

            var toAirport = entities.Airports.ToList();
            comboBox2.DisplayMember = "IATACode";
            comboBox2.ValueMember = "ID";
            comboBox2.DataSource = toAirport;

            var cabinTypes = entities.CabinTypes.ToList();
            comboBox3.DisplayMember = "Name";
            comboBox3.ValueMember = "ID";
            comboBox3.DataSource = cabinTypes;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;

            if(rb.Checked)
            {
                if(rb.Tag.ToString().Equals("1"))
                {
                    dateTimePicker2.Enabled = false;
                }
                else if(rb.Tag.ToString().Equals("2"))
                {
                    dateTimePicker2.Enabled = true;
                }
            }
        }

        public static string FlattenFlightNumber(List<Schedule> schedules)
        {
            string flightNumbers = "";

            for (int i = 0; i < schedules.Count; i++)
            {
                flightNumbers += schedules[i].FlightNumber;

                if(i != schedules.Count - 1)
                {
                    flightNumbers += " - ";
                }
            }

            return flightNumbers;
        }

        public static decimal GetPrice(List<Schedule> schedules, CabinType cabinType)
        {
            decimal totalPrice = 0;

            for (int i = 0; i < schedules.Count; i++)
            {
                decimal price = schedules[i].EconomyPrice;

                if(cabinType.ID == 2)
                {
                    price = price * 135 / 100;
                }
                else if(cabinType.ID == 3)
                {
                    price = (price * 135 / 100) * 130 / 100;
                }

                totalPrice += price;
            }

            return totalPrice;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var checkedRDB = groupBox1.Controls
                .Cast<Control>()
                .Where(x => x.GetType() == typeof(RadioButton))
                .Cast<RadioButton>()
                .Where(x => x.Checked)
                .FirstOrDefault();

            if(comboBox1.SelectedIndex == -1 || comboBox2.SelectedIndex == -1 || comboBox3.SelectedIndex == -1 || checkedRDB == null)
            {
                MessageBox.Show("All parameters must be filled!");
            }
            else
            {
                bookingType = Int32.Parse(checkedRDB.Tag.ToString());
                outboundDate = new DateTime(dateTimePicker1.Value.Year, dateTimePicker1.Value.Month, dateTimePicker1.Value.Day);
                returnDate = new DateTime(1, 1, 1);
                Airport deptAirport = comboBox1.SelectedItem as Airport;
                Airport arrivalAirport = comboBox2.SelectedItem as Airport;
                cabinType = comboBox3.SelectedItem as CabinType;

                if (deptAirport.ID == arrivalAirport.ID)
                {
                    MessageBox.Show("Departure and arrival airport must not be the same!");
                }
                else
                {
                    dataGridView1.DataSource = null;
                    dataGridView2.DataSource = null;

                    if (bookingType == 2)
                    {
                        returnDate = new DateTime(dateTimePicker2.Value.Year, dateTimePicker2.Value.Month, dateTimePicker2.Value.Day);

                        if (returnDate <= outboundDate)
                        {
                            MessageBox.Show("Return date must be after outbound date!");
                            return;
                        }
                    }

                    var schedules = entities.Schedules.Where(x => x.Confirmed).ToList();
                    List<DateTime> dates = new List<DateTime>();
                    for (int i = -3; i <= 3; i++)
                    {
                        DateTime date = outboundDate.AddDays(i);
                        dates.Add(date);
                    }

                    var filtered = schedules.Where(x => x.Date >= dates[0]).ToList();
                    outboundRoutes = new List<List<Schedule>>();
                    FindRoute(filtered, deptAirport, arrivalAirport, dates, new TimeSpan(), new List<Schedule>(), ref outboundRoutes);
                    FillOutboundDgv();

                    if (bookingType == 2)
                    {
                        dates = new List<DateTime>();
                        for (int i = -3; i <= 3; i++)
                        {
                            DateTime date = returnDate.AddDays(i);
                            dates.Add(date);
                        }

                        filtered = schedules.Where(x => x.Date >= dates[0]).ToList();
                        returnRoutes = new List<List<Schedule>>();
                        FindRoute(filtered, arrivalAirport, deptAirport, dates, new TimeSpan(), new List<Schedule>(), ref returnRoutes);
                        FillReturnDgv();
                    }
                }
            }
        }

        private void FillOutboundDgv()
        {
            if (checkBox1.Checked)
            {
                var outboundDgvData = outboundRoutes
                    .Select(x => new
                    {
                        From = x.First().Route.Airport.IATACode,
                        To = x.Last().Route.Airport1.IATACode,
                        Date = x.First().Date.ToString("dd/MM/yyyy"),
                        Time = x.First().Time.ToString(@"hh\:mm"),
                        FlightNumbers = FlattenFlightNumber(x),
                        CabinPrice = Math.Floor(GetPrice(x, cabinType)),
                        NumberOfStops = x.Count - 1,
                        Schedules = new Schedules() { schedules = x }
                    }).ToList();

                dataGridView1.DataSource = outboundDgvData;
                dataGridView1.Columns["Schedules"].Visible = false;
            }
            else
            {
                var outboundDgvData = outboundRoutes
                    .Where(x => x.First().Date == outboundDate)
                    .Select(x => new
                    {
                        From = x.First().Route.Airport.IATACode,
                        To = x.Last().Route.Airport1.IATACode,
                        Date = x.First().Date.ToString("dd/MM/yyyy"),
                        Time = x.First().Time.ToString(@"hh\:mm"),
                        FlightNumbers = FlattenFlightNumber(x),
                        CabinPrice = Math.Floor(GetPrice(x, cabinType)),
                        NumberOfStops = x.Count - 1,
                        Schedules = new Schedules() { schedules = x }
                    }).ToList();

                dataGridView1.DataSource = outboundDgvData;
                dataGridView1.Columns["Schedules"].Visible = false;
            }
        }

        private void FillReturnDgv()
        {
            if (checkBox2.Checked)
            {
                var returnDgvData = returnRoutes
                    .Select(x => new
                    {
                        From = x.First().Route.Airport.IATACode,
                        To = x.Last().Route.Airport1.IATACode,
                        Date = x.First().Date.ToString("dd/MM/yyyy"),
                        Time = x.First().Time.ToString(@"hh\:mm"),
                        FlightNumbers = FlattenFlightNumber(x),
                        CabinPrice = Math.Floor(GetPrice(x, cabinType)),
                        NumberOfStops = x.Count - 1,
                        Schedules = new Schedules() { schedules = x }
                    }).ToList();

                dataGridView2.DataSource = returnDgvData;
                dataGridView2.Columns["Schedules"].Visible = false;
            }
            else
            {
                var returnDgvData = returnRoutes
                    .Where(x => x.First().Date == returnDate)
                    .Select(x => new
                    {
                        From = x.First().Route.Airport.IATACode,
                        To = x.Last().Route.Airport1.IATACode,
                        Date = x.First().Date.ToString("dd/MM/yyyy"),
                        Time = x.First().Time.ToString(@"hh\:mm"),
                        FlightNumbers = FlattenFlightNumber(x),
                        CabinPrice = Math.Floor(GetPrice(x, cabinType)),
                        NumberOfStops = x.Count - 1,
                        Schedules = new Schedules() { schedules = x }
                    }).ToList();

                dataGridView2.DataSource = returnDgvData;
                dataGridView2.Columns["Schedules"].Visible = false;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            FillOutboundDgv();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if(bookingType == 2)
            {
                FillReturnDgv();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string totalPassenger = textBox1.Text.Trim();
            int passenger = 0;

            if(dataGridView1.CurrentCell == null)
            {
                MessageBox.Show("Please select outbound flight schedule!");
            }
            else if(totalPassenger.Equals(""))
            {
                MessageBox.Show("Please fill total passengers!");
            }
            else if(!Int32.TryParse(totalPassenger, out passenger))
            {
                MessageBox.Show("Total passenger must be numeric!");
            }
            else
            {
                if(bookingType == 2)
                {
                    if(dataGridView2.CurrentCell == null)
                    {
                        MessageBox.Show("Please select return flight schedule!");
                        return;
                    }
                }

                DataGridViewCell outboundCell = dataGridView1.CurrentCell;
                Schedules outboundSchedules = dataGridView1.Rows[outboundCell.RowIndex].Cells["Schedules"].Value as Schedules;
                bool outboundAvailable = CheckSeatAvailability(outboundSchedules.schedules, cabinType, passenger);

                if(!outboundAvailable)
                {
                    MessageBox.Show($"Available seat is not enough for {passenger} persons!");
                }
                else
                {
                    if(bookingType == 2)
                    {
                        DataGridViewCell returnCell = dataGridView2.CurrentCell;
                        Schedules returnSchedules = dataGridView2.Rows[returnCell.RowIndex].Cells["Schedules"].Value as Schedules;
                        bool returnAvailable = CheckSeatAvailability(returnSchedules.schedules, cabinType, passenger);

                        if (!returnAvailable)
                        {
                            MessageBox.Show($"Available seat is not enough for {passenger} persons!");
                        }
                        else
                        {
                            List<List<Schedule>> schedules = new List<List<Schedule>>();
                            schedules.Add(outboundSchedules.schedules);
                            schedules.Add(returnSchedules.schedules);
                            BookingConfirmationForm form = new BookingConfirmationForm(this, bookingType, schedules, passenger, cabinType);
                            form.Show();
                            this.Hide();
                        }
                    }
                    else
                    {
                        List<List<Schedule>> schedules = new List<List<Schedule>>();
                        schedules.Add(outboundSchedules.schedules);
                        BookingConfirmationForm form = new BookingConfirmationForm(this, bookingType, schedules, passenger, cabinType);
                        form.Show();
                        this.Hide();
                    }
                }
            }
        }

        private bool CheckSeatAvailability(List<Schedule> schedules, CabinType cabinType, int passenger)
        {
            var tickets = entities.Tickets.ToList();

            foreach (Schedule schedule in schedules)
            {
                var booked = tickets
                    .Where(x =>
                        x.ScheduleID == schedule.ID &&
                        x.CabinTypeID == cabinType.ID &&
                        x.Confirmed)
                    .Count();

                int available = 0;
                if (cabinType.ID == 1)
                {
                    available = schedule.Aircraft.EconomySeats;
                }
                else if (cabinType.ID == 2)
                {
                    available = schedule.Aircraft.BusinessSeats;
                }
                else if (cabinType.ID == 3)
                {
                    available = schedule.Aircraft.TotalSeats - schedule.Aircraft.EconomySeats - schedule.Aircraft.BusinessSeats;
                }

                available -= booked;
                if (available < passenger)
                {
                    return false;
                }
            }

            return true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FindRoute(List<Schedule> schedules, Airport from, Airport to, List<DateTime> dates, TimeSpan time, List<Schedule> visited, ref List<List<Schedule>> availableRoutes)
        {
            if(from.ID == to.ID)
            {
                availableRoutes.Add(visited);
            }
            else
            {
                var visitedAirport = visited.Select(x => x.Route.DepartureAirportID).ToList();
                var routes = schedules.Where(x =>
                        x.Route.DepartureAirportID == from.ID &&
                        !visitedAirport.Contains(x.Route.ArrivalAirportID) &&
                        dates.Any(y => y == x.Date && x.Date + x.Time >= y + time))
                    .ToList();

                foreach (var route in routes)
                {
                    List<Schedule> visit = new List<Schedule>(visited);
                    visit.Add(route);

                    var filtered = schedules.Where(x => x.Date >= route.Date).ToList();
                    TimeSpan flightTime = new TimeSpan(0, route.Route.FlightTime, 0);
                    DateTime arrivalDate = route.Date + route.Time + flightTime;
                    DateTime date = new DateTime(arrivalDate.Year, arrivalDate.Month, arrivalDate.Day);
                    FindRoute(filtered, route.Route.Airport1, to, new List<DateTime>() { date }, arrivalDate - date, visit, ref availableRoutes);
                }
            }
        }
    }
}
