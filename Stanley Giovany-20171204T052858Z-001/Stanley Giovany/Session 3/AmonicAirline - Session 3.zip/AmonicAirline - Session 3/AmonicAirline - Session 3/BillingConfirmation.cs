﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmonicAirline
{
    public partial class BillingConfirmation : Form
    {
        session3Entities entities = new session3Entities();
        List<List<Schedule>> schedules;
        int passenger, bookingType;
        CabinType cabinType;
        Form source;
        List<Passenger> passengers;

        public BillingConfirmation(Form source, int bookingType, List<List<Schedule>> schedules, int passenger, CabinType cabinType, List<Passenger> passengers)
        {
            InitializeComponent();

            this.passengers = passengers;
            this.source = source;
            this.bookingType = bookingType;
            this.schedules = schedules;
            this.passenger = passenger;
            this.cabinType = cabinType;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            source.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var checkedRDB = this.Controls.Cast<Control>()
                .Where(x => x.GetType() == typeof(RadioButton))
                .Cast<RadioButton>()
                .Where(x => x.Checked)
                .FirstOrDefault();

            if(checkedRDB == null)
            {
                MessageBox.Show("Please select one payment method!");
            }
            else
            {
                //List<User> users = new List<User>();
                //int userId = GenerateUserId();

                //for (int i = 0; i < passengers.Count; i++)
                //{
                //    User user = new User()
                //    {
                //        ID = passengers[i].ID,
                //        FirstName = passengers[i].FirstName,
                //        LastName = passengers[i].LastName,
                //        Birthdate = passengers[i].Birthdate,
                //        Active = true,
                //        RoleID = 2,
                //        Email = "",
                //        Password = ""
                //    };

                //    users.Add(user);
                //}

                //entities.Users.AddRange(users);
                //entities.SaveChanges();

                string bookingReference = GenerateBookingReference();

                List<Ticket> tickets = new List<Ticket>();
                List<Schedule> allSchedules = new List<Schedule>(schedules[0]);
                if(bookingType == 2) allSchedules.AddRange(schedules[1]);

                for (int i = 0; i < allSchedules.Count; i++)
                {
                    for (int j = 0; j < passengers.Count; j++)
                    {
                        Passenger p = passengers[j];
                        Ticket ticket = new Ticket()
                        {
                            UserID = 1,
                            ScheduleID = allSchedules[i].ID,
                            CabinTypeID = cabinType.ID,
                            Firstname = p.FirstName,
                            Lastname = p.LastName,
                            Phone = p.Phone,
                            PassportNumber = p.PassportNumber,
                            PassportCountryID = p.Country.ID,
                            BookingReference = bookingReference,
                            Confirmed = true
                        };

                        tickets.Add(ticket);
                    }
                }

                entities.Tickets.AddRange(tickets);
                entities.SaveChanges();

                source = null;
                MessageBox.Show("Booking saved!");

                SearchFlightForm form = new SearchFlightForm();
                form.Show();
                this.Close();
            }
        }

        public static int GenerateUserId()
        {
            session3Entities entities = new session3Entities();
            int id = 0;
            User user = entities.Users.OrderByDescending(x => x.ID).FirstOrDefault();

            if(user != null)
            {
                id = user.ID;
            }

            id++;
            return id;
        }

        public static string GenerateBookingReference()
        {
            session3Entities entities = new session3Entities();
            string texts = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            Random rand = new Random();
            string bookingCode = "";
            Ticket ticket;

            do
            {
                bookingCode = "";

                for (int i = 0; i < 6; i++)
                {
                    int idx = rand.Next(texts.Length);
                    bookingCode += texts[idx];
                }

                ticket = entities.Tickets.Where(x => x.BookingReference.Equals(bookingCode)).FirstOrDefault();
            } while (ticket != null);

            return bookingCode;
        }

        private void BillingConfirmation_Load(object sender, EventArgs e)
        {
            List<Schedule> allSchedules = new List<Schedule>(schedules[0]);
            if(bookingType == 2) allSchedules.AddRange(schedules[1]);

            lblAmount.Text = $"$ {SearchFlightForm.GetPrice(allSchedules, cabinType) * passenger:0}";
        }
    }
}
