﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmonicAirline
{
    public partial class FlightData : UserControl
    {
        string AirportFrom, AirportTo, CabinType, Date, FlightNumber;

        public FlightData(string airportFrom, string airportTo, string cabinType, string date, string flightNumber)
        {
            InitializeComponent();

            AirportFrom = airportFrom;
            AirportTo = airportTo;
            CabinType = cabinType;
            Date = date;
            FlightNumber = flightNumber;
        }

        private void FlightData_Load(object sender, EventArgs e)
        {
            label2.Text = AirportFrom;
            label4.Text = AirportTo;
            label6.Text = CabinType;
            label8.Text = Date;
            label10.Text = FlightNumber;
        }
    }
}
