﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AmonicAirline
{
    class SurveyData
    {
        public string Question { get; set; }
        public string Choice { get; set; }
        public string Gender { get; set; }
        public string Age { get; set; }
        public string CabinType { get; set; }
        public string DestinationAirport { get; set; }
    }
}
