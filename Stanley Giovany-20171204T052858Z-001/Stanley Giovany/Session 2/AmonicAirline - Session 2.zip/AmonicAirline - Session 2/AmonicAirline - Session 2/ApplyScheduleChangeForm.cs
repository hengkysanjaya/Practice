﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace AmonicAirline
{
    public partial class ApplyScheduleChangeForm : Form
    {
        session2Entities entities = new session2Entities();

        public ApplyScheduleChangeForm()
        {
            InitializeComponent();
        }

        private List<string> ReadFile(string path)
        {
            List<string> lines = new List<string>();

            try
            {
                Excel.Application xlApp = new Excel.Application();
                Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(path);
                Excel.Worksheet xlWorksheet = xlWorkbook.Worksheets[1];

                int row = 1;
                while (xlWorksheet.Cells[row, 1].Value != null)
                {
                    string line = "";

                    for (int i = 1; i <= 9; i++)
                    {
                        if (xlWorksheet.Cells[row, i].Value != null)
                        {
                            if (i == 2)
                            {
                                try
                                {
                                    DateTime date = xlWorksheet.Cells[row, i].Value;
                                    line += date.ToString("M/d/yyyy");
                                }
                                catch (Exception) { }
                            }
                            else if (i == 3)
                            {
                                try
                                {
                                    DateTime date = DateTime.FromOADate(xlWorksheet.Cells[row, i].Value);
                                    line += date.ToString("H:mm");
                                }
                                catch (Exception) { }
                            }
                            else
                            {
                                line += xlWorksheet.Cells[row, i].Value.ToString();
                            }

                            if (i != 9)
                            {
                                line += ",";
                            }
                        }
                        else
                        {
                            break;
                        }
                    }

                    lines.Add(line);
                    row++;
                }

                xlWorkbook.Close();
                xlApp.Quit();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return lines;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string path = openFileDialog1.FileName;
                string ext = Path.GetExtension(path);

                if(ext.ToLower().Equals(".xlsx"))
                {
                    MessageBox.Show("File extension must be .csv!");
                }
                else
                {
                    try
                    {
                        List<string> lines = ReadFile(path);
                        int missing = 0, success = 0;
                        var schedules = new List<Schedule>();

                        for (int i = 0; i < lines.Count; i++)
                        {
                            string[] contents = lines[i].Split(',');
                            DateTime date;
                            TimeSpan time;

                            if (contents.Length != 9)
                            {
                                missing++;
                            }
                            else if (!DateTime.TryParseExact(contents[1], "M/d/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out date))
                            {
                                missing++;
                            }
                            else if (!TimeSpan.TryParseExact(contents[2], @"h\:mm", new CultureInfo("en-US"), TimeSpanStyles.None, out time))
                            {
                                missing++;
                            }
                            else
                            {
                                string operation = contents[0];
                                string flightNumber = contents[3];
                                string deptAirport = contents[4];
                                string arrAirport = contents[5];
                                string aircraftCode = contents[6];
                                string basePrice = contents[7];
                                string confirmation = contents[8];
                                int airCode = 0, price = 0;

                                if (!operation.Equals("ADD") && !operation.Equals("EDIT"))
                                {
                                    missing++;
                                }
                                else if (!Int32.TryParse(basePrice, out price))
                                {
                                    missing++;
                                }
                                else if (!Int32.TryParse(aircraftCode, out airCode))
                                {
                                    missing++;
                                }
                                else if (!confirmation.Equals("OK") && !confirmation.Equals("CANCELED"))
                                {
                                    missing++;
                                }
                                else
                                {
                                    Airport dept = entities.Airports.Where(x => x.IATACode.Equals(deptAirport)).FirstOrDefault();
                                    Airport arrival = entities.Airports.Where(x => x.IATACode.Equals(arrAirport)).FirstOrDefault();
                                    Aircraft aircraft = entities.Aircrafts.Where(x => x.ID == airCode).FirstOrDefault();

                                    if (dept == null || arrival == null || aircraft == null)
                                    {
                                        missing++;
                                    }
                                    else
                                    {
                                        Route route = entities.Routes
                                            .Where(x => x.DepartureAirportID == dept.ID && x.ArrivalAirportID == arrival.ID)
                                            .FirstOrDefault();

                                        if (route == null)
                                        {
                                            missing++;
                                        }
                                        else
                                        {
                                            if (operation.Equals("ADD"))
                                            {
                                                Schedule schedule = new Schedule()
                                                {
                                                    FlightNumber = flightNumber,
                                                    Date = date,
                                                    Time = time,
                                                    AircraftID = aircraft.ID,
                                                    EconomyPrice = price,
                                                    RouteID = route.ID,
                                                    Confirmed = confirmation.Equals("OK") ? true : false
                                                };

                                                schedules.Add(schedule);
                                            }
                                            else
                                            {
                                                Schedule schedule = entities.Schedules
                                                    .Where(x => x.Date == date && x.FlightNumber.Equals(flightNumber))
                                                    .FirstOrDefault();

                                                if (schedule == null)
                                                {
                                                    missing++;
                                                }
                                                else
                                                {
                                                    schedule.Time = time;
                                                    schedule.AircraftID = aircraft.ID;
                                                    schedule.EconomyPrice = price;
                                                    schedule.RouteID = route.ID;
                                                    schedule.Confirmed = confirmation.Equals("OK") ? true : false;

                                                    success++;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        int scheduleToAdd = schedules.Count;
                        schedules = schedules.GroupBy(x => new
                        {
                            x.Date,
                            x.FlightNumber
                        })
                            .Select(x => x.ToList().First())
                            .ToList();
                        int nonDuplicateSchedule = schedules.Count;

                        entities.Schedules.AddRange(schedules);
                        entities.SaveChanges();

                        lblSuccess.Text = $"{success + nonDuplicateSchedule}";
                        lblMissing.Text = missing.ToString();
                        lblDuplicate.Text = $"{scheduleToAdd - nonDuplicateSchedule}";
                    }catch(Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }
    }
}
