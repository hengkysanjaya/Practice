﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmonicAirline
{
    public partial class ManageFlightForm : Form
    {
        session2Entities entities = new session2Entities();
        Airport from = null, to = null;
        string flightNo = "", sort = "Date-Time";
        bool hasDate = false;
        DateTime flightDate = new DateTime(1, 1, 1);

        public ManageFlightForm()
        {
            InitializeComponent();
        }

        private void ManageFlightForm_Load(object sender, EventArgs e)
        {
            var fromAirports = entities.Airports.ToList();
            fromAirports.Add(new Airport() { ID = 0, Name = "All airports" });
            fromAirports = fromAirports.OrderBy(x => x.ID).ToList();
            comboBox1.DisplayMember = "Name";
            comboBox1.ValueMember = "ID";
            comboBox1.DataSource = fromAirports;

            var toAirports = entities.Airports.ToList();
            toAirports.Add(new Airport() { ID = 0, Name = "All airports" });
            toAirports = toAirports.OrderBy(x => x.ID).ToList();
            comboBox2.DisplayMember = "Name";
            comboBox2.ValueMember = "ID";
            comboBox2.DataSource = toAirports;

            var sortBy = new List<string>()
            {
                "Date-Time", "EconomyPrice", "Confirmed"
            };
            comboBox3.DataSource = sortBy;

            GetFlightSchedules(false, new DateTime(1, 1, 1), null, null, "", "Date-Time");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string dateString = maskedTextBox1.Text;
            string flightNo = textBox1.Text.Trim();
            string sort = "";

            Airport from = null, to = null;
            DateTime flightDate = new DateTime(1, 1, 1);
            bool hasDate = false;

            if (!dateString.Equals(""))
            {
                if (DateTime.TryParseExact(dateString,
                                           "dd/MM/yyyy",
                                           new CultureInfo("en-US"),
                                           DateTimeStyles.None, out flightDate))
                {
                    hasDate = true;
                }
            }

            if(comboBox1.SelectedIndex != -1)
            {
                from = comboBox1.SelectedItem as Airport;

                if(from.ID == 0)
                {
                    from = null;
                }
            }
            
            if(comboBox2.SelectedIndex != -1)
            {
                to = comboBox2.SelectedItem as Airport;

                if(to.ID == 0)
                {
                    to = null;
                }
            }

            if(comboBox3.SelectedIndex != -1)
            {
                sort = comboBox3.SelectedItem as string;
            }

            if(from != null && to != null && from.ID == to.ID)
            {
                MessageBox.Show("Departure and arrival airports cannot be the same!");
            }
            else
            {
                this.from = from;
                this.to = to;
                this.flightDate = flightDate;
                this.sort = sort;
                this.flightNo = flightNo;
                this.hasDate = hasDate;
                
                GetFlightSchedules(hasDate, flightDate, from, to, flightNo, sort);
            }
        }

        private void GetFlightSchedules(bool hasDate, DateTime date, Airport from, Airport to, string flightNo, string sort)
        {
            var flightSchedules = entities.Schedules.ToList();

            if(hasDate)
            {
                flightSchedules = flightSchedules.Where(x => x.Date == date).ToList();
            }
            
            if(from != null)
            {
                flightSchedules = flightSchedules.Where(x => x.Route.DepartureAirportID == from.ID).ToList();
            }

            if(to != null)
            {
                flightSchedules = flightSchedules.Where(x => x.Route.ArrivalAirportID == to.ID).ToList();
            }

            if(!flightNo.Equals(""))
            {
                flightSchedules = flightSchedules.Where(x => x.FlightNumber.Equals(flightNo)).ToList();
            }

            if(!sort.Equals(""))
            {
                if(sort.Equals("Date-Time"))
                {
                    flightSchedules = flightSchedules.OrderByDescending(x => x.Date + x.Time).ToList();
                }
                else if(sort.Equals("EconomyPrice"))
                {
                    flightSchedules = flightSchedules.OrderByDescending(x => x.EconomyPrice).ToList();
                }
                else if(sort.Equals("Confirmed"))
                {
                    flightSchedules = flightSchedules.OrderByDescending(x => x.Confirmed).ToList();
                }
            }

            var dgvData = flightSchedules.Select(x => new
            {
                ScheduleId = x.ID,
                Date = x.Date.ToString("dd/MM/yyyy"),
                Time = x.Time.ToString(@"hh\:mm"),
                From = x.Route.Airport.IATACode,
                To = x.Route.Airport1.IATACode,
                FlightNumber = x.FlightNumber,
                Aircraft = x.Aircraft.Name,
                EconomyPrice = "$" + Math.Floor(x.EconomyPrice),
                BusinessPrice = "$" + Math.Floor(x.EconomyPrice * 135 / 100),
                FirstClassPrice = "$" + Math.Floor((x.EconomyPrice * 135 / 100) * 130 / 100),
                Confirmed = x.Confirmed
            }).ToList();

            dataGridView1.DataSource = dgvData;
            dataGridView1.Columns["Confirmed"].Visible = false;
            dataGridView1.Columns["ScheduleId"].Visible = false;

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                bool confirmed = (bool)dataGridView1.Rows[i].Cells["Confirmed"].Value;

                if(!confirmed)
                {
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.Red;
                    dataGridView1.Rows[i].DefaultCellStyle.ForeColor = Color.White;
                }
            }

            dataGridView1.CurrentCell = null;
            button2.Text = "Cancel / Confirm Flight";
        }

        private void maskedTextBox1_Validating(object sender, CancelEventArgs e)
        {
            string dateString = maskedTextBox1.Text;
            DateTime date;

            if (dateString.Equals(""))
            { 
                if (!DateTime.TryParseExact(dateString,
                                           "dd/MM/yyyy",
                                           new CultureInfo("en-US"),
                                           DateTimeStyles.None, out date))
                {
                    maskedTextBox1.Text = "";
                    MessageBox.Show("Date format is dd/MM/yyyy");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(dataGridView1.CurrentCell == null)
            {
                MessageBox.Show("Please select a flight schedule in datagridview!");
            }
            else
            {
                DataGridViewCell cell = dataGridView1.CurrentCell;
                int id = (int)dataGridView1.Rows[cell.RowIndex].Cells["ScheduleId"].Value;

                Schedule schedule = entities.Schedules
                    .Where(x => x.ID == id)
                    .FirstOrDefault();

                ScheduleEditForm form = new ScheduleEditForm(schedule);
                if(form.ShowDialog() == DialogResult.OK)
                {
                    entities = new session2Entities();
                    GetFlightSchedules(hasDate, flightDate, from, to, flightNo, sort);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ApplyScheduleChangeForm form = new ApplyScheduleChangeForm();
            form.ShowDialog();
            entities = new session2Entities();
            GetFlightSchedules(hasDate, flightDate, from, to, flightNo, sort);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0)
            {
                bool confirmed = (bool)dataGridView1.Rows[e.RowIndex].Cells["Confirmed"].Value;

                if(confirmed)
                {
                    button2.Text = "Cancel Flight";
                }
                else
                {
                    button2.Text = "Confirm Flight";
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(dataGridView1.CurrentCell == null)
            {
                MessageBox.Show("Please select a flight schedule in datagridview!");
            }
            else
            {
                DataGridViewCell cell = dataGridView1.CurrentCell;
                bool confirmed = (bool)dataGridView1.Rows[cell.RowIndex].Cells["Confirmed"].Value;
                int id = (int)dataGridView1.Rows[cell.RowIndex].Cells["ScheduleId"].Value;

                Schedule schedule = entities.Schedules.Where(x => x.ID == id).FirstOrDefault();
                schedule.Confirmed = !confirmed;
                entities.SaveChanges();

                GetFlightSchedules(hasDate, flightDate, from, to, flightNo, sort);
            }
        }
    }
}
