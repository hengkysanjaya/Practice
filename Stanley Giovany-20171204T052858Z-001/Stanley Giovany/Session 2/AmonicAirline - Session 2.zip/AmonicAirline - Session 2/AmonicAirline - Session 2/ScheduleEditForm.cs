﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmonicAirline
{
    public partial class ScheduleEditForm : Form
    {
        session2Entities entities = new session2Entities();
        Schedule Schedule;

        public ScheduleEditForm(Schedule schedule)
        {
            InitializeComponent();

            Schedule = schedule;
        }

        private void ScheduleEditForm_Load(object sender, EventArgs e)
        {
            Schedule schedule = entities.Schedules
                .Where(x => x.ID == Schedule.ID)
                .FirstOrDefault();

            lblFrom.Text = schedule.Route.Airport.IATACode;
            lblTo.Text = schedule.Route.Airport1.IATACode;
            lblAircraft.Text = schedule.Aircraft.Name;

            maskedTextBox1.Text = schedule.Date.ToString("dd/MM/yy");
            maskedTextBox2.Text = schedule.Time.ToString(@"hh\:mm");
            textBox1.Text = Math.Floor(schedule.EconomyPrice).ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string dateString = maskedTextBox1.Text;
            string timeString = maskedTextBox2.Text;
            string price = textBox1.Text;
            int economyPrice = 0;
            DateTime date;
            TimeSpan time;

            if(dateString.Equals("") || timeString.Equals("") || price.Equals(""))
            {
                MessageBox.Show("All fields are required!");
            }
            else if(!Int32.TryParse(price, out economyPrice))
            {
                MessageBox.Show("Price must be numeric!");
            }
            else if(economyPrice <= 0)
            {
                MessageBox.Show("Price must greater than 0!");
            }
            else if(!DateTime.TryParseExact(dateString, "dd/MM/yy", new CultureInfo("en-US"), DateTimeStyles.None, out date))
            {
                MessageBox.Show("Date must be filled!");
            }
            else if(!TimeSpan.TryParseExact(timeString, @"hh\:mm", new CultureInfo("en-US"), TimeSpanStyles.None, out time))
            {
                MessageBox.Show("Time must be filled!");
            }
            else
            {
                Schedule schedule = entities.Schedules
                    .Where(x => x.ID == Schedule.ID)
                    .FirstOrDefault();

                schedule.Date = date;
                schedule.Time = time;
                schedule.EconomyPrice = economyPrice;

                entities.SaveChanges();
                DialogResult = DialogResult.OK;
            }
        }

        private void maskedTextBox1_Validating(object sender, CancelEventArgs e)
        {
            string dateString = maskedTextBox1.Text;
            DateTime date;

            if (!dateString.Equals(""))
            {
                if (!DateTime.TryParseExact(dateString, "dd/MM/yy", new CultureInfo("en-US"), DateTimeStyles.None, out date))
                {
                    maskedTextBox1.Text = Schedule.Date.ToString("dd/MM/yy");
                    MessageBox.Show("Date format must be dd/MM/yy");
                }
            }
        }

        private void maskedTextBox2_Validating(object sender, CancelEventArgs e)
        {
            string timeString = maskedTextBox2.Text;
            TimeSpan time;

            if(!timeString.Equals(""))
            {
                if(!TimeSpan.TryParseExact(timeString, @"hh\:mm", new CultureInfo("en-US"), TimeSpanStyles.None, out time))
                {
                    maskedTextBox2.Text = Schedule.Time.ToString(@"hh\:mm");
                    MessageBox.Show("Time format must be HH:mm");
                }
            }
        }
    }
}
